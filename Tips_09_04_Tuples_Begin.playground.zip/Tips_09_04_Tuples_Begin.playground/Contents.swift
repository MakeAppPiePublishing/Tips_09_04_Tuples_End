//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

//:# Introduction to Tuples
import MapKit

//: An example of a Tuple with CLLocationDegrees(i.e. Double) and String
let pizzaPlace = (40.7216,-73.9955,name:"Lombardi's")
let clCoordinate = CLLocationCoordinate2D(latitude: pizzaPlace.0, longitude: pizzaPlace.1)
let name = pizzaPlace.name

func coordinate(coordinate:(Double,Double,String)) -> CLLocationCoordinate2D{
    return CLLocationCoordinate2D(latitude: coordinate.0, longitude: coordinate.1)
}

coordinate(coordinate: pizzaPlace)
var coord2 = pizzaPlace
coord2.name = "New York"
coord2.name
pizzaPlace.name

func locationDescription(name:String,city:String) -> (String,String){
    return (name,city)
}

let ld = locationDescription(name: "Gino's east", city: "Chicago")

let (restaurant,city) = ld
restaurant
city




